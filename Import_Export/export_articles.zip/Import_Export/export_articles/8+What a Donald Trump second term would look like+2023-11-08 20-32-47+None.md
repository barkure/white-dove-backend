![swqas](https://ichef.bbci.co.uk/news/976/cpsprodpb/17FC9/production/_131594289_trump_second_term_index_promo_2x_976x549-nc.png.webp)
**Donald Trump has devoted much of this presidential campaign looking back, contesting his 2020 election defeat. But behind the scenes, he and his team are putting together a plan for power, determined to avoid the mistakes of 2016.**  

For those wondering what Mr Trump intends to do if American voters send him back to the White House in 12 months, the former president is laying it all out.  

It's there in bite-size chunks on his campaign website, it's heard at his rally speeches and it's documented by people he has entrusted to work on his second term preparations.  

They call the plan Agenda47 - a reference to Mr Trump becoming America's 47th president if he wins. He is favourite to win the Republican nomination, which would pit him against Democratic President Joe Biden next November.  

ADVERTISEMENT  

Eight years ago, when Donald Trump launched his unlikely bid to win the White House race, he did so with a shoestring budget and a ragtag staff of political outsiders and hangers-on.  

He had a slogan, Make America Great Again. He had a few tentpole policies, like building a border wall and temporarily banning Muslims from entering the US. And he had an anti-establishment, drain-the-swamp attitude.  

After his upset victory, he set about turning his broad political vision into action - but with mixed results.  

His "Muslim ban" was repeatedly struck down by courts, before finally becoming policy in its diluted form. His pledge to build a border wall was derailed by lawsuits and congressional Democrats.  

It was, in the view of those in Mr Trump's circle, a failure of preparation and a failure of personnel.  

Those were mistakes they don't intend to repeat if they win in 2024.  
___  
Moments after Mr Trump had given his inauguration speech on 20 January, 2017, he walked into the Oval Office at 6.55pm with Marc Lotter who worked on his transition team.  

From the discussions that followed, Mr Lotter quickly realised the administration just wasn't equipped to deal with "moving the Titanic-sized ship of government", he tells the BBC.  

This time, he and other veterans of the Trump presidency are making sure they are better prepared, he says, and they're crafting a plan.  

"Here's a playbook. Here's how you get it done. And here, most importantly, are the areas and the places and positions where a liberal bureaucracy is going to try to stop you."  

![dwe](https://ichef.bbci.co.uk/news/976/cpsprodpb/11CCE/production/_131601927_aid_to_ukraine_index_promo_2x_975x549-nc.png.webp)  
That playbook has revealed itself over the course of the year.  

Some of his pronouncements border on the fantastical. His government will invest in flying cars and build "freedom cities" on empty federal land, where Americans can live and work without burdensome regulations.  

Others are controversial, such as his plan to round up the homeless and move them to tent camps outside US cities until their "problems can be identified". Some lean directly into the culture wars - he wants state school teachers to be required to "embrace patriotic values".